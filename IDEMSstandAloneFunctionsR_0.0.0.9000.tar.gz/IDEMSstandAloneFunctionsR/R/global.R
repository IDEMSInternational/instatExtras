utils::globalVariables(c("Element", "Value", "value", "element.na", "From", "Date.ym", "na", "is.complete", "To", "Date.y", "Level", "count", "no",
                         ".data", "month_name_english","month_abb_english",
                         "av_packs","fq","labels_label","data_unstacked",".","level.out",
                         "countriesHigh","countriesLow","<<-"))
